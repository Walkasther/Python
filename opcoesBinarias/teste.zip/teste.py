from iqoptionapi.stable_api import IQ_Option
import time

# Configurações iniciais
email = 'mateuswalkasther@gmail.com'
senha = 'Iq#2015'
valor_inicial = 2
multiplicador = 2.2
usar_conta_real = False  # Defina como True para usar a conta real, False para conta de treinamento
tipo = 'binarias'

# Conectar à plataforma IQ Option
iq = IQ_Option(email, senha)
iq.connect()

# Verificar conexão
if iq.check_connect():
    print("Conectado com sucesso!")
else:
    print("Erro ao conectar")
    exit()

# Selecionar conta
if usar_conta_real:
    iq.change_balance("REAL")
    print("Usando conta real.")
else:
    iq.change_balance("PRACTICE")
    print("Usando conta de treinamento.")


# Função para realizar operações
def realizar_operacao(valor, direcao):
    status, id = iq.buy(valor, "EURUSD-OTC", direcao, 1)  # 1 representa a expiração de 1 minuto
    return status, id


# Função principal de trading
def trading():
    valor = valor_inicial
    while True:
        # Alternar entre compra e venda
        for direcao in ["put", "call"]:
            if tipo == 'digital':
                #check -> essa variavel vai receber true ou false, indicando se a transação foi feita ou não
                #id -> Retorna o id da transação caso a variavel check for  true, ou um erro caso não de para abrir uma transação
                status, id = iq.buy_digital_spot_v2("EURUSD-OTC",valor, direcao, 1)
            else:
                status, id = iq.buy(valor, "EURUSD-OTC", direcao, 1)

            if status: 
                print(f"Operação {direcao} com valor R$ {valor:.2f} realizada com sucesso.")
                # Verificar resultado da operação
                while True:
                    time.sleep(0.1)
                    status, lucro = iq.check_win_digital_v2(id) if tipo == 'digital' else iq.check_win_v4(id)
                    if status:
                        if lucro > 0:
                            print(f"Operação {direcao} ganhou. Lucro: {lucro}")
                            valor = valor_inicial  # Resetar valor após ganho
                        elif lucro == 0:
                            print(f"Operação {direcao} empatou. Saldo: {lucro}")
                        else:
                            print(f"Operação {direcao} perdeu. Perda: {lucro}")
                            valor *= multiplicador  # Multiplicar valor após perda
                        break
            else:
                print(f"Erro ao realizar operação {direcao}. Tentando novamente...")
                time.sleep(60)  # Esperar 1 minuto antes da próxima operação


# Iniciar trading
trading()